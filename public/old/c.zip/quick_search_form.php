<tr>
                        <td align="left" class="sachingray"><p class="sitename style37">Quick Search </p></td>
                      </tr>
                      <tr>
                        <td height="23" align="left" valign="top"><p class="style31">Search based on a criteria one would look for in a partner.</p></td>
                      </tr>
                      <tr>
                        <td valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="48" valign="top" class="inborder"><form action="" method="post" name="form3" id="form3">
                            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2" class="rowstyle">
                              <tr>
                                <td width="29%">&nbsp;</td>
                                <td width="60%" height="18">&nbsp;</td>
                              </tr>
                              <tr>
                                <td align="right"><p><font face="Verdana, Arial, sans-serif, Tahoma">Looking 
                                  for : </font></p></td>
                                <td height="21" align="left"><p>
                                  <input name="gender" type="radio" class="t3" value="male" checked="checked" />
Male&nbsp;&nbsp;&nbsp;&nbsp;
<input name="gender" type="radio" class="t3" value="female" />
Female </p></td>
                              </tr>
                              <tr>
                                <td align="right"><p><font face="Verdana, Arial, sans-serif, Tahoma">Age between  : </font></p></td>
                                <td align="left"><p><font size="1" face="Verdana, Arial, sans-serif, Tahoma">
                                  <select style="WIDTH: 44px" name="agefrom">
                                    <option>18</option>
                                    <option>19</option>
                                    <option selected="selected">20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option>28</option>
                                    <option>29</option>
                                    <option>30</option>
                                    <option>31</option>
                                    <option>32</option>
                                    <option>33</option>
                                    <option>34</option>
                                    <option>35</option>
                                    <option>36</option>
                                    <option>37</option>
                                    <option>38</option>
                                    <option>39</option>
                                    <option>40</option>
                                    <option>41</option>
                                    <option>42</option>
                                    <option>43</option>
                                    <option>44</option>
                                    <option>45</option>
                                    <option>46</option>
                                    <option>47</option>
                                    <option>48</option>
                                    <option>49</option>
                                    <option>50</option>
                                    <option>51</option>
                                    <option>52</option>
                                    <option>53</option>
                                    <option>54</option>
                                    <option>55</option>
                                    <option>56</option>
                                    <option>57</option>
                                    <option>58</option>
                                    <option>59</option>
                                    <option>60</option>
                                    <option>61</option>
                                    <option>62</option>
                                    <option>63</option>
                                    <option>64</option>
                                    <option>65</option>
                                    <option>66</option>
                                    <option>67</option>
                                    <option>68</option>
                                    <option>69</option>
                                    <option>70</option>
                                  </select>
                                  <font color="#000000" size="1" face="Verdana, Arial, sans-serif, Tahoma">to</font>
                                  <select style="WIDTH: 44px" name="ageto">
                                    <option>18</option>
                                    <option>19</option>
                                    <option>20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option selected="selected">28</option>
                                    <option>29</option>
                                    <option>30</option>
                                    <option>31</option>
                                    <option>32</option>
                                    <option>33</option>
                                    <option>34</option>
                                    <option>35</option>
                                    <option>36</option>
                                    <option>37</option>
                                    <option>38</option>
                                    <option>39</option>
                                    <option>40</option>
                                    <option>41</option>
                                    <option>42</option>
                                    <option>43</option>
                                    <option>44</option>
                                    <option>45</option>
                                    <option>46</option>
                                    <option>47</option>
                                    <option>48</option>
                                    <option>49</option>
                                    <option>50</option>
                                    <option>51</option>
                                    <option>52</option>
                                    <option>53</option>
                                    <option>54</option>
                                    <option>55</option>
                                    <option>56</option>
                                    <option>57</option>
                                    <option>58</option>
                                    <option>59</option>
                                    <option>60</option>
                                    <option>61</option>
                                    <option>62</option>
                                    <option>63</option>
                                    <option>64</option>
                                    <option>65</option>
                                    <option>66</option>
                                    <option>67</option>
                                    <option>68</option>
                                    <option>69</option>
                                    <option>70</option>
                                    <option>71</option>
                                    <option>72</option>
                                    <option>73</option>
                                    <option>74</option>
                                    <option>75</option>
                                    <option>76</option>
                                    <option>77</option>
                                    <option>78</option>
                                    <option>79</option>
                                    <option>80</option>
                                    <option>81</option>
                                    <option>82</option>
                                    <option>83</option>
                                    <option>84</option>
                                    <option>85</option>
                                    <option>86</option>
                                    <option>87</option>
                                    <option>88</option>
                                    <option>89</option>
                                    <option>90</option>
                                  </select>
                                </font></p></td>
                              </tr>
                              <tr>
                                <td align="right"><p><font face="Verdana, Arial, sans-serif, Tahoma">Religion :</font></p></td>
                                <td align="left"><p>
                                  <select name="religion" id="religion">
                                    <option selected="selected">Any </option>
                                      <option>Hindu </option>
                                      <option>Muslim </option>
                                      <option>Muslim - Shia </option>
                                      <option>Muslim - Sunni </option>
                                      <option>Christian </option>
                                      <option>Christian - Catholic </option>
                                      <option>Christian - Orthodox </option>
                                      <option>Christian - Protestant </option>
                                      <option>Sikh </option>
                                      <option>Jain </option>
                                      <option>Jain - Digambar </option>
                                      <option>Jain - Shwetambar </option>
                                      <option>Parsi </option>
                                      <option>Buddhist </option>
                                      <option>Inter Religion </option>
                                      <option>No Religion </option>
                                  </select>
                                </p></td>
                              </tr>
                              <tr>
                                <td height="23" align="right"><p><font face="Verdana, Arial, sans-serif, Tahoma">Mother Tongue  :</font></p></td>
                                <td align="left"><p>
                                  <select name="language" id="language">
                                    <option selected="selected">Any</option>
                                    <option>Aka</option>
                                    <option>Arabic</option>
                                    <option>Assamese</option>
                                    <option>Awadhi</option>
                                    <option>Bengali</option>
                                    <option>Bhojpuri</option>
                                    <option>Bhutia</option>
                                    <option>Chatlisgarhi</option>
                                    <option>Chinese</option>
                                    <option>Dogri</option>
                                    <option>English</option>
                                    <option>French</option>
                                    <option>Garhwali</option>
                                    <option>Garo</option>
                                    <option>Gujarati</option>
                                    <option>Haryanvi</option>
                                    <option>Hindi</option>
                                    <option>Kakbarak</option>
                                    <option>Kanauji</option>
                                    <option>Kannada</option>
                                    <option>Kashmiri</option>
                                    <option>Khandesi</option>
                                    <option>Khasi</option>
                                    <option>Konkani</option>
                                    <option>Koshali</option>
                                    <option>Kumoani</option>
                                    <option>Kutchi</option>
                                    <option>Lepcha</option>
                                    <option>Magahi</option>
                                    <option>Maithili</option>
                                    <option>Malay</option>
                                    <option>Malayalam</option>
                                    <option>Manipuri</option>
                                    <option>Marathi</option>
                                    <option>Marwari</option>
                                    <option>Miji</option>
                                    <option>Mizo</option>
                                    <option>Monpa</option>
                                    <option>Nepali</option>
                                    <option>Oriya</option>
                                    <option>Persian</option>
                                    <option>Punjabi</option>
                                    <option>Rajasthani</option>
                                    <option>Russian</option>
                                    <option>Sanskrit</option>
                                    <option>Santhali</option>
                                    <option>Sindhi</option>
                                    <option>Spanish</option>
                                    <option>Swedish</option>
                                    <option>Tamil</option>
                                    <option>Tagalog</option>
                                    <option>Telugu</option>
                                    <option>Tulu</option>
                                    <option>Urdu</option>
                                    <option>Other</option>
                                  </select>
                                </p></td>
                              </tr>
                              
                               <tr>
                                <td height="23">&nbsp;</td>
                                <td align="left"><p>
                                  <input type="submit" name="submit" value="Search" />
                                </p></td>
                              </tr>
                            </table>
                        </form></td>
                      </tr>
                      <tr>
                        <td height="19" valign="top">&nbsp;</td>
                      </tr>
                    </table>