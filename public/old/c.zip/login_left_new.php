<table>

<form action="index.php" method="post" name="loginForm" id="loginForm" onsubmit="return validateFields()">
<tr>
	<td style="color: purple;">Profile ID :</td><td><input name="email" required></td>
</tr>
	<tr><td style="color: purple;">Password : </td><td><input name="password" type="password" required></td>
</tr>
	<tr><td></td><td><input type="submit" title="Login" value="Login"></td>
</tr>
</form>
</table>