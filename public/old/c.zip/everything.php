<div class="mtop">
<div class="mctext">
MangalMandap.com, the site where singles become couples. It's free to sign up, so Register NOW!<br></div>
<img src="images/logo_name.png" width="280" height="120" />
<div id="box1">
<?php
	if(isset($_SESSION["me"])){
		echo "<div style='float: left; margin-top: 15px;'>Welcome, <a href='manage.php' title='Manage Account' class='white'>".$_SESSION["me"]["name"]."</a>! &nbsp;&nbsp;&nbsp;<a href='logout.php' title='Logout' class='white'>Logout</a></div>";
	}
?>
</div>
<div class="mmenu">
<div id='cssmenu'>
<ul>
   <li class='active'><a href='#'>Home</a></li>
   <li><a href='#'>Register</a></li>
   <li><a href='#'>Member Login</a></li>
    <li><a href='#'>Member Login</a></li>
	<li><a href='#'>Partner Search</a></li>
   <li><a href='#'>Membership</a></li>
   <li><a href='#'>Payment Option</a></li>
   <li><a href='#'>Contact Us</a></li>
</ul>
</div>
</div>
</div>        

<div id="leftbox">
<div class="userlogin">
<?php
	if(isset($_SESSION["me"]))
	{
		echo "";
	}
	else{
		include("login_left_new.php");
	}
?>
</div>
<center><img src="images/add3.gif" width="100%"/></center>
</div>
<div class="box2">  <img src="images/wall4.jpg">   
</div>	
<div id="box3">
<img src="images/centerlink.jpg" width="80%" height="100px" />
</div>
<div id="profilebox"> 
  
<table>
<tr>
<?php
						
		$conn= new mysqli("localhost","mangaztt_user","Ajit@@123","mangaztt_marriagedb");
		if($conn->connect_error)
		{
			die("Connection Failed: ". $conn->connect_error);
		}
		else
		{	
			$random_sql="SELECT id FROM activate WHERE active='yes' ORDER BY RAND() LIMIT 5";
			$result=mysqli_query($conn, $random_sql);
			while($random=$result->fetch_assoc()){
				$detail_sql="SELECT name, city FROM profiles WHERE id=".$random["id"];
				$random_sql2="SELECT pic1 FROM images WHERE id=".$random["id"];
				$detail=mysqli_fetch_assoc(mysqli_query($conn, $detail_sql));
				$pic=mysqli_fetch_assoc(mysqli_query($conn, $random_sql2));
				
				echo "<td width='110' height='104' align='center' valign='top'><a href='registration.php'><img src='".$pic["pic1"]."' width='65' height='80' border='1'></a><br>
    <font size='1' face='Tahoma' color='#FF3399'>".$detail["name"]."<br>".$random["id"]."<br>".$detail["city"]."</font></td>";
			}
			echo "</tr><tr>";
			$random_sql="SELECT id FROM activate WHERE active='yes' ORDER BY RAND() LIMIT 5";
			$result=mysqli_query($conn, $random_sql);
			while($random=$result->fetch_assoc()){
				$detail_sql="SELECT name, city FROM profiles WHERE id=".$random["id"];
				$random_sql2="SELECT pic1 FROM images WHERE id=".$random["id"];
				$detail=mysqli_fetch_assoc(mysqli_query($conn, $detail_sql));
				$pic=mysqli_fetch_assoc(mysqli_query($conn, $random_sql2));
				
				echo "<td width='110' height='104' align='center' valign='top'><a href='registration.php'><img src='".$pic["pic1"]."' width='65' height='80' border='1'></a><br>
    <font size='1' face='Tahoma' color='#FF3399'>".$detail["name"]."<br>".$random["id"]."<br>".$detail["city"]."</font></td>";
			}
		}
?>
</tr>
</table>
</div>
<div style="float: right; width: 30%; height: auto;">


<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#F2EDF3">
                        <tr>
                          <td height="27" colspan="2" align="left" class="style6"><p class="style6">Affiliate Login</p></td>
                        </tr>
                        
                        <tr>
                          <td width="38%" align="right" valign="middle" class="style3">User ID </td>
                          <td height="24" align="left" valign="middle">
                            &nbsp;&nbsp;
                            <input name="uid" id="email" tabindex="33" size="16" style="height:11px; width:70px;" onkeypress="javascript:return chk4schar();" onkeydown="javascript: return chk4id();" /></td>
                        </tr>
                        
                        <tr>
                          <td align="right" valign="middle" class="style3">Password&nbsp;</td>
                          <td height="24" align="left" valign="middle">
                            &nbsp;&nbsp;
                            <input name="pass" type="password" id="password" style="height:11px; width:70px;" tabindex="34" size="16" maxlength="14" onkeydown="javascript: return chk4pass();"/>                          </td>
                        </tr>
                        
                        <tr>
                          <td>&nbsp;</td>
                          <td height="22">&nbsp;&nbsp;
                            <input name="login" type="submit" title="Login" accesskey="13" tabindex="32" value=Login width="14" height="14" alt="Member Login" class="t1" /></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td width="62%" valign="bottom"></td>
                        </tr>
                      </table>
</div>
  

  
<div class="footer">
<br><br>
Home  |  Registration  |  Member Login  |  Partner Search  |  Membership  |  Terms & Conditions  |  Payment Option  |  About us  |  Privacy Policy  |  Contact us</div>
