
				
				
<form name="form1" method="post" action="">

	<tr valign="top">
        <td height="15" align="right">&nbsp;</td>
        <td height="15">&nbsp;</td>
    </tr>
	
	<tr valign="top">
        <td height="24" align="right"><p class="style18"><strong>Enter Profile ID:</strong></p></td>
          <td height="24"><p><strong>
            <input name="id_dlt" type="text" id="old_pass" size="18" maxlength="8"required/>
              </strong></p></td>
    </tr>
	
	<tr valign="top">
        <td height="15" align="right">&nbsp;</td>
        <td height="15">&nbsp;</td>
    </tr>
	
	
	
	<tr valign="top">
        
		<br>
		<td></td>
		<td><p align="left"><input type="submit" name="delete" value="Delete" /></p><</td>
	</tr>
</form>

