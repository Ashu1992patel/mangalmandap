<body ondragstart="return false" onselectstart="return false" oncontextmenu="return false" onload=runSlideShow();MM_preloadimages('images/home_h.jpg','images/registration_h.jpg','images/login_h.jpg','images/search_h.jpg','images/membership_h.jpg','images/payment_h.jpg','images/contact_h.jpg')>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top" background="images/top_bg.jpg" bgcolor="#EAE4E6" style="background-repeat:repeat-x;"><table width="1000" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="mainborder">
      <tr>
        <td height="50" align="left" valign="middle" bgcolor="#87004F" class="phead"><font face="Arial"> <div style="float:left; width:200px; height:50px; font-size:25px;color:white;">
        
        </div><center valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></font></td>
      </tr>
      
      <tr>
        <td background="images/header_bg.jpg" style="background-repeat:repeat-x; background-size:100% 8.3%""><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="2%" align="left" valign="top" bgcolor="#F2EDF3"><img src="images/header_bg.jpg" width="22" height="81" /></td>
            <td width="22%" height="423" align="left" valign="top"><table width="94%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="81" align="left" valign="middle">
                    <table width="219" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td colspan="2" align="left"><p class="phead style7"></p></td>
                        </tr>
                      <tr>
                        <td width="39%" align="left"></td>
                        <td width="61%" align="left"><p>
                            
                        </p></td>
                      </tr>
                    </table>
                </td>
              </tr>
              <tr>
                <td height="15" align="left" valign="top" bgcolor="#F2EDF3"><img src="images/spacer.gif" width="219" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="index.php" onmouseout=MM_swapImgRestore() onmouseover=MM_swapImage('home','','images/home1_h.jpg',1)><img src=images/home1.jpg name=home width=166 height=26 border=0 id=home/></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><img src="images/button_sap.jpg" width="166" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="registration.php" onmouseout=MM_swapImgRestore() onmouseover=MM_swapImage('reg','','images/registration1_h.jpg',1)><img src=images/registration1.jpg name=reg width=166 height=34 border=0 id=reg/></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><img src="images/button_sap.jpg" width="166" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="memberlogin.php" onmouseout=MM_swapImgRestore() onmouseover=MM_swapImage('mlog','','images/login1_h.jpg',1)><img src=images/login1.jpg name=mlog width=166 height=31 border=0 id=mlog/></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><img src="images/button_sap.jpg" width="166" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="partnersearch.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image15','','images/search_h.jpg',1)"><img src="images/search.jpg" alt="Search Your Partner here" name="Image15" width="166" height="33" border="0" id="Image15" /></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><img src="images/button_sap.jpg" width="166" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="Membership.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image17','','images/membership1_h.jpg',1)"><img src="images/membership1.jpg" alt="Membership of Mangal Mandap" name="Image17" width="166" height="32" border="0" id="Image17" /></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><img src="images/button_sap.jpg" width="166" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="payment.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image19','','images/payment_h.jpg',1)"><img src="images/payment.jpg" alt="How to Pay?" name="Image19" width="166" height="33" border="0" id="Image19" /></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><img src="images/button_sap.jpg" width="166" height="1" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" bgcolor="#F2EDF3"><a href="contact.php" onmouseout=MM_swapImgRestore() onmouseover=MM_swapImage('log','','images/contact1_h.jpg',1)><img src=images/contact1.jpg name=log width=166 height=24 border=0 id=log/></a></td>
              </tr>