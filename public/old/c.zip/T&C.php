<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.managalmandap.com/T&C.asp by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Jun 2015 08:39:11 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Mangal Mandap (Marriage Center for Central  India)</title>

<link href="style.css" type="text/css" rel="stylesheet" />

<script type="text/JavaScript">
<!--
function MM_preloadimages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadimages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
.style4 {color: #FFFF00; font-size:10px;}
-->
</style>
</head>

<body onload=runSlideShow();MM_preloadimages('images/inhome_h.jpg','images/inregistration_h.jpg','images/inlogin_h.jpg','images/insearch_h.jpg','images/inmembership_h.jpg','images/inpayment_h.jpg','images/incontact_h.jpg')>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top" background="images/top_bg.jpg" bgcolor="#EAE4E6" style="background-repeat:repeat-x;"><table width="1000" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="mainborder">
      <tr>
        <td height="50" align="center" valign="middle" bgcolor="#87004F" class="phead">MangalMandap.com, the site where singles become couples. It's free to sign up, so Register NOW! </td>
      </tr>
      <tr>
        <td background="images/header_bg.jpg" style="background-repeat:repeat-x;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="2%" height="81" align="left" valign="top" bgcolor="#F2EDF3"><img src="images/header_bg.jpg" width="22" height="81" /></td>
            <td width="98%" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="2%" align="right" valign="top"><img src="images/headerbox_L.jpg" width="18" height="81" /></td>
                <td width="96%" align="right" valign="top" background="images/headerbox_C.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="99%" valign="bottom">&nbsp;</td>
                    <td width="1%" align="right" valign="top"><img src="images/logo_name.jpg" width="262" height="81" /></td>
                  </tr>
                </table></td>
                <td width="2%" align="right" valign="top"><img src="images/headerbox_R.jpg" width="35" height="81" /></td>
              </tr>
              
              
            </table></td>
          </tr>
          <tr>
            <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
            <td align="left" valign="top" bgcolor="#FFFFFF"><table width="98%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="left" valign="top"><table width="99%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td colspan="7"><img src="images/spacer.gif" width="1" height="4" /></td>
                  </tr>
                  <tr>
                    <td width="9%" align="left" valign="top"><a href="index.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image19','','images/inhome_h.jpg',1)"><img src="images/inhome.jpg" alt="Mangal Mandap" name="Image19" width="88" height="40" border="0" id="Image19" /></a></td>
                    <td width="14%" align="left" valign="top"><a href="registration.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image20','','images/inregistration_h.jpg',1)"><img src="images/inregistration.jpg" name="Image20" width="133" height="40" border="0" id="Image20" /></a></td>
                    <td width="16%" align="left" valign="top"><a href="memberlogin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image21','','images/inlogin_h.jpg',1)"><img src="images/inlogin.jpg" name="Image21" width="149" height="40" border="0" id="Image21" /></a></td>
                    <td width="16%" align="left" valign="top"><a href="partnersearch.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image22','','images/insearch_h.jpg',1)"><img src="images/insearch.jpg" name="Image22" width="155" height="40" border="0" id="Image22" /></a></td>
                    <td width="14%" align="left" valign="top"><a href="Membership.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','images/inmembership_h.jpg',1)"><img src="images/inmembership.jpg" name="Image23" width="135" height="40" border="0" id="Image23" /></a></td>
                    <td width="18%" align="left" valign="top"><a href="payment.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image24','','images/inpayment_h.jpg',1)"><img src="images/inpayment.jpg" name="Image24" width="163" height="40" border="0" id="Image24" /></a></td>
                    <td width="13%" align="left" valign="top"><a href="contact.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image25','','images/incontact_h.jpg',1)"><img src="images/incontact.jpg" name="Image25" width="134" height="40" border="0" id="Image25" /></a></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><img src="images/title_t%26c.jpg" width="320" height="43" /></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="left" valign="top">&nbsp;</td>
                    <td align="center" valign="middle">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="78%" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">

                      <tr>
                        <td align="left" valign="top"><p class="onebig"> <strong>Dear User </strong></p></td>
                      </tr>
                      
                      <tr>
                        <td align="left" valign="top"><p>Please read this Terms &amp; Conditions before registration. By registring on <span class="sitename">MangalMandap.com</span> you   explicitly understand and agree that :  </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="3%" align="center" valign="middle"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td width="97%"><p> The minimum age for registering is 18 years for women and 21 years for men. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="middle"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p> You are not disabled by any law from entering into a contract. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="middle"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p> You have gone through the Terms and Conditions and agree to be bound by them. </p></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">Electronic Communications </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p align="justify"> When you visit<strong>&nbsp;</strong><span class="sitename">MangalMandap.com</span>&nbsp;or send e-mails to us, you are communicating with us electronically. You consent to receive communications from us electronically. We will communicate with you by e-mail or by posting notices on this site. You agree that all agreements, notices, disclosures and other communications that we provide to you electronically satisfy any legal requirement that such communications be in writing </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">Your Account </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p align="justify"> If you use this site, you are responsible for maintaining the confidentiality of your account and password and for restricting access to your computer, and you agree to accept responsibility for all activities that occur under your account or password.<strong>&nbsp;</strong><span class="sitename">MangalMandap.com</span>&nbsp;and its affiliates reserve the right to refuse service, terminate accounts, remove or edit content, or cancel subscription in their sole discretion. </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">Role of MangalMandap.com </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="3%" align="center" valign="middle"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td width="97%"><p> <strong>Provision of Service</strong> </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="middle">&nbsp;</td>
                            <td><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp;will provide the service that are opted and paid for by the member. In addition, the member may also make use of the other free services that are applicable to them. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="middle"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p> <strong>Medium of Interchange of Information</strong></p></td>
                          </tr>
                          <tr>
                            <td align="center" valign="middle">&nbsp;</td>
                            <td><p align="justify"> Besides the provision of services,&nbsp;<span class="sitename">MangalMandap.com</span>&nbsp;acts as a platform for all its members to interchange information that would promote their common matrimonial objectives. It is to be distinctly understood that <span class="sitename">MangalMandap.com</span> will only provide contact between and among members within its service framework and not the direct contact details of such members </p></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">Refund of Fee </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p align="justify">If you choose to terminate your membership, the MEMBERSHIP FEES ARE NOT REFUNDABLE under any circumstances. Your membership in the&nbsp;<span class="sitename">MangalMandap.com</span>&nbsp;service is for your sole, personal use. You may not authorize others to use your membership and you may not assign or transfer your account to any other person or entity.</p>                          </td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">Online Conduct </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td width="97%"><p> Being a free member you can express your interest to a limited number of members. This is valid for a limited period only </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp;shall not be responsible for any passing of information etc. between any member via e-mail, chat or any other mediation with another member. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp;is not the agent of any member and does not partake in the interchange or the results thereof.&nbsp;<span class="sitename">MangalMandap.com</span>will be a disinterested person in the event of disputes between or among the members, though it may facilitate an amicable resolution of such disputes. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp;under no circumstances shall be responsible for any loss or damage resulting from anyone's use of the Site or the Service and&nbsp; or any Content posted or transmitted to Members. The exchange of matrimonial profile(s) through our site should not in any way be construed as a matrimonial offer or recommendation by our site. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p align="justify"> Any advice, counseling, recommendations or information provided at&nbsp;<span class="sitename">MangalMandap.com</span>. including information of&nbsp;<span class="sitename">MangalMandap.com</span>&nbsp;members may not be necessarily correct, true or reliable, and that any reliance placed thereon and any action taken on the basis thereof shall be entirely solely at the risk of the person or persons placing such reliance or taking such action. Visitors wishing to use the information so provided are advised to conduct their own due diligence, in respect of the site content sought to be taken advantage of, at their own initiative, cost and effort. </p></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">Disclaimer of Warranties &amp; Limitation of Liability</p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p align="justify"> This site is provided by&nbsp;<span class="sitename">MangalMandap.com</span>&nbsp;on an &quot;as is&quot; and &quot;as available&quot; basis.&nbsp;<span class="sitename">MangalMandap.com</span>&nbsp;makes no representations or warranties of any kind, express or implied, as to the operation of this site or the information, content, materials, or products included on this site. you expressly agree that your use of this site is at your sole risk. </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><p class="onebig">As to Extraneous Contents </p></td>
                      </tr>
                      <tr>
                        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td width="97%"><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp;reserves the right to delete any content, message, photo, profile or cancel the registration , membership of such individual&nbsp; either upon a complaint received from another member group of individuals or upon discovery of the same on its own or based on its sole judgment and perception and it shall without notice stop providing the service entitled to a member and forfeit all other incidental service with immediate effect along with the fee of registration as well as take appropriate legal action against such member. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp;reserves the right to verify the authenticity of Content posted on the site Mangal Mandap, if circumstances warrant may call for any of its members to provide documentary or other form of evidence supporting the information posted on the site and the member, without any protest shall produce such evidence in support of such information and if the member fails to produce such information within a reasonable or stipulated time frame,<span class="sitename"> MangalMandap</span>&nbsp;may terminate such Membership and forfeit the advance without a refund and take appropriate steps under the provisions of law. </p></td>
                          </tr>
                          <tr>
                            <td width="3%" align="center" valign="top"><p><img src="images/arrows.jpg" width="8" height="8" /></p></td>
                            <td><p align="justify"> <span class="sitename">MangalMandap.com</span>&nbsp; has no obligation to monitor the activities of its members. However, it has the right to monitor the Site electronically from time to time and to disclose any information as necessary to satisfy any law, regulation or other governmental request, to operate the Site properly, or to protect itself or its subscribers.&nbsp;<span class="sitename">MangalMandap.com</span>&nbsp;&nbsp;will not intentionally monitor or disclose any private electronic-mail message unless required by law. </p></td>
                          </tr>
                        </table></td>
                      </tr>
                      
                    </table></td>
                    <td width="22%" align="right" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="center" valign="top"><p><img src="images/add3.gif" width="185" height="410" /></p></td>
                      </tr>
                      <tr>
                        <td height="80">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="right" valign="top"><p><img src="images/add2.jpg" width="195" height="495" /></p></td>
                      </tr>
                      <tr>
                        <td height="60" align="right" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="center" valign="top"><img src="images/clickhere.jpg" width="150" height="100" /></td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      
      
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" background="images/down_bg.jpg" bgcolor="#A20055" style="background-repeat:repeat-x"><table width="1002" border="0" cellpadding="0" cellspacing="0">
      
      <tr>
        <td height="30" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td height="24" align="center" valign="middle"><script src="downlink.js" type="text/javascript" language="javascript"></script></td>
      </tr>
      <tr>
         
      </tr>
    </table></td>
  </tr>
</table>

<map name="Map2" id="Map2"><area shape="rect" coords="17,107,91,135" href="franchise.php" />
</map>
<map name="Map3" id="Map3">
<area shape="circle" coords="78,64,63" href="cg.php" />
</map>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/57894cf03daf03937c742256/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
</body>

<!-- Mirrored from www.managalmandap.com/T&C.asp by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Jun 2015 08:39:25 GMT -->
</html>