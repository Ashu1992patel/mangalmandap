document.write("  <a href=index.php class=downlink>Home</a>");
document.write(" <font color=#000000>&nbsp;|&nbsp; <a href=registration.php class=downlink>Registration</a>");
document.write(" &nbsp;|&nbsp; <a href=memberlogin.php class=downlink>Member Login</a>");
document.write(" &nbsp;|&nbsp; <a href=partnersearch.php class=downlink>Partner Search</a> ");
document.write(" &nbsp;|&nbsp; <a href=membership.php class=downlink>Membership</a>");
document.write(" &nbsp;|&nbsp; <a href=T&C.php class=downlink>Terms & Conditions</a> ");
document.write(" &nbsp;|&nbsp; <a href=payment.php class=downlink>Payment Option</a>");
//document.write(" &nbsp;|&nbsp; <a href=about.php class=downlink>About us</a>");
//document.write(" &nbsp;|&nbsp; <a href=policy.php class=downlink>	Privacy Policy</a>");
document.write(" &nbsp;|&nbsp; <a href=contact.php class=downlink>Contact us</a></font>");
//document.write(" | <a href=sitemap.htm class=title>Site map</a>")
//document.write("<a href=payment.htm class=title>How to Pay</a>")
//document.write(" | <a href=PaymentDetail.htm class=title>Payment Detail</a>")
//document.write(" | <a href=MatrimonialProg.htm class=title>Special Service</a></font>")

