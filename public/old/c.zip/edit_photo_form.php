
<form action="" method="post" name="form1" id="form1" enctype="multipart/form-data">
     <table width="98%" border="0" align="center" cellpadding="1" cellspacing="1">
        <tr valign="top">
            <td height="21" colspan="2"><p class="style12">Update your photos <span class="style13">. </span></p></td>
        </tr>
        <tr valign="top">
			<td height="30" align="right"><p><strong>Photo 1: </strong></p></td>
			<td height="30"><p><strong>
			<input name="pic[]" type="file" id="pic" />
            </td>
		</tr>
		<tr valign="top">
			<td height="30" align="right"><p><strong>Photo 2: </strong></p></td>
			<td height="30"><p><strong>
			<input name="pic[]" type="file" id="pic" />
            </td>
		</tr>
		<tr valign="top">
			<td height="30" align="right"><p><strong>Photo 3: </strong></p></td>
			<td height="30"><p><strong>
			<input name="pic[]" type="file" id="pic" />
            </td>
			<br>
			<td><input type="submit" name="upload" value="Upload" /></td>
		</tr>
						
						
						
        <tr valign="top">
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
    </table>
</form>
